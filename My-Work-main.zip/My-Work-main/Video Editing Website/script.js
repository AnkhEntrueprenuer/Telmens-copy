let dubaitext = document.getElementById('dubaitext');
let burjkhalifa = document.getElementById('burjkhalifa');
let stars = document.getElementById('stars');
const faqs = document.querySelectorAll(".FAQ");

faqs.forEach((FAQ) => {
    FAQ.addEventListener("click", () => {
        FAQ.classList.toggle("active");
    });
});

window.addEventListener('scroll', () => {
    let value = window.scrollY;

    dubaitext.style.left = value * -2 + 'px';
    burjkhalifa.style.top = value * 1 + 'px';
    stars.style.top = value * 1 + 'px';
});

Static.SQUARESPACE_CONTEXT.tweakJSON["tweak-overlay-parallax-enabled"] = false;